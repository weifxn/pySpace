# pySpace
**pySpace** is a simple python grid game.


You can [download it here](https://github.com/weifan23/pySpace/archive/master.zip). 

You need to download [Python 3.6](https://www.python.org/downloads/) to run this game.

	
	$ python3 pySpace.py


![game](https://i.imgur.com/alljbar.png)

The objective in this game is to reach the end 'x' without finishing your fuel.
 
Each move costs 5 fuel, 
each steps costs 1 fuel.
